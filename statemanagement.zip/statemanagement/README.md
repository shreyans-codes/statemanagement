# statemanagement

An application that fetches news and presents it in small swipable cards.

## How it fetches news

I am using the news api to fetch the news and in the previous version I had added the ability to choose your language.
In this version, I have tried to implement cards and save news locally via local database. It is still under implemntation.
